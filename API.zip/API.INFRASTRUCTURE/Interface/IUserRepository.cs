﻿using API.HRM.DOMAIN;


namespace API.INFRASTRUCTURE
{
    public interface IUserRepository : IRepositoryBase<User>
    {
    }
}
