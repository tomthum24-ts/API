﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.HRM.DOMAIN
{
    public class TableConstants
    {
        public const string User_TABLENAME = "User";
        public const string AttachmentFile_TABLENAME = "AttachmentFile";
    }
}
