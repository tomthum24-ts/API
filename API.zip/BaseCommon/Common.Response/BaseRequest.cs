﻿namespace API
{
    public class BaseRequest
    {
        public string UserID { get; set; }
    }
}
